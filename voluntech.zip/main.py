from fastapi import FastAPI, HTTPException, Request, Query, Form
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from datetime import datetime, timedelta, timezone
from typing import Dict
from models import volunteer, organization
from fastapi.security import HTTPBasic
from fastapi.staticfiles import StaticFiles
from database import volunteer_collection, organization_collection, sessions_collection
import bcrypt
import re
import secrets
from datetime import datetime
from pymongo.collection import Collection
from database import sessions_collection
from models import User, volunteer, organization
security = HTTPBasic()
verification_tokens = {}  # Dictionary to store verification tokens
app = FastAPI()
# Mount static files directory
app.mount("/templates", StaticFiles(directory="templates"), name="static")
# Define Jinja templates directory
templates = Jinja2Templates(directory="templates")
# In-memory session storage (for demonstration purposes)
sessions: Dict[str, dict] = {}

  
# Root landing page
@app.get("/", response_class=HTMLResponse)
async def landing_page(request: Request):
    return templates.TemplateResponse("landing_page.html", {"request": request})

# Route for handling login form submission
@app.post("/login/")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    # Check if username exists in either volunteer or organization collections
    user = volunteer_collection.find_one({"email": username}) or organization_collection.find_one({"email": username})
    if not user or not verify_password(password, user["hashed_password"]):
        # Invalid username or password
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    
    # Create session token and store it
    session_token = create_session_token(username)
    expiration_time = datetime.now() + timedelta(days=1)
    store_session_token(session_token, username, expiration_time)

    # Redirect to volunteer or organization page based on user type
    if "skills" in user:
        return RedirectResponse(url="/volunteer", status_code=303)
    elif "city" in user:
        return RedirectResponse(url="/organization", status_code=303)
    else:
        # Handle unknown user type
        return Response("Unknown user type", status_code=500)
    # Render dashboard page
    return templates.TemplateResponse("dashboard.html", {"request": request, "username": session_data["username"]})
# Route for rendering signup selection page
@app.get("/register", response_class=HTMLResponse)
async def get_signup_selection(request: Request):
    return templates.TemplateResponse("register_selection.html", {"request": request})

# Route for handling signup form submission
@app.route("/register/", methods=["GET", "POST"])
async def handle_signup(request: Request):
    if request.method == "GET":
        # Render the signup selection page
        return templates.TemplateResponse("register_selection.html", {"request": request})
    elif request.method == "POST":
        # Process the signup form submission
        form_data = await request.form()
        user_type = form_data.get("user_type")
        if user_type == "volunteer":
            return RedirectResponse(url="/register/volunteer")
        elif user_type == "organization":
            return RedirectResponse(url="/register/organization")
        else:
            # Handle invalid user type selection
            return RedirectResponse(url="/signup?error=invalid_user_type")
        
@app.route("/register/volunteer", methods=["GET", "POST"])
async def register_volunteer(request: Request):
    if request.method == "GET":
        # Handle GET request
        return templates.TemplateResponse("volunteer/register_volunteer.html", {"request": request})
    elif request.method == "POST":
        # Handle POST request
        # Add your code to process the POST request here
        return templates.TemplateResponse("volunteer/register_volunteer.html", {"request": request})

# Route for handling volunteer skills selection form submission
@app.post("/register/volunteer/skills", response_class=HTMLResponse)
async def submit_volunteer_skills(request: Request, volunteer: volunteer):
    # Save volunteer skills to the database
    volunteer_data = {
        "email": volunteer.email,
        "skills": volunteer.skills
    }
    volunteer_collection.insert_one(volunteer_data)
    
    # Redirect to next step: volunteer cause selection
    return RedirectResponse("/register/volunteer/cause")

# Route for volunteer cause selection
@app.get("/register/volunteer/cause", response_class=HTMLResponse)
async def get_volunteer_cause_page(request: Request):
    return templates.TemplateResponse("/volunteer/volunteer_cause.html", {"request": request})

# Route for handling volunteer cause selection form submission
@app.post("/register/volunteer/cause", response_class=HTMLResponse)
async def submit_volunteer_cause(request: Request, volunteer: volunteer):
    # Save volunteer cause selection to the database
    email = volunteer.email
    cause = volunteer.cause
    volunteer_collection.update_one({"email": email}, {"$set": {"cause": cause}})
    
    # Redirect to confirmation page
    return RedirectResponse("/register/volunteer/confirm")

# Route for displaying confirmation page
@app.get("/register/volunteer/confirm", response_class=HTMLResponse)
async def get_volunteer_confirmation_page(request: Request):
    return templates.TemplateResponse("volunteer/confirmation_volunteer.html", {"request": request})

# Route for registering organization
@app.route("/register/organization", methods=["GET", "POST"])
async def organization_volunteer(request: Request):
    if request.method == "GET":
        # Handle GET request
        return templates.TemplateResponse("organization/register_organization.html", {"request": request})
    elif request.method == "POST":
        # Handle POST request
        # Add your code to process the POST request here
        return templates.TemplateResponse("organization/register_organization.html", {"request": request})

# Register endpoint for organizations
@app.post("/organization/register/")
async def register_organization(organization: organization):
    # Check if email is already in use
    if organization_collection.find_one({"email": organization.email}):
        raise HTTPException(status_code=400,
                            detail="Email already in use. Please use another email or reset your password.")

    # Check if password meets complexity requirements
    if not is_password_complex(organization.password):
        raise HTTPException(status_code=400, detail="Password does not meet complexity requirements")

    # If email is unique and password meets requirements, proceed with registration
    organization_data = {
        "First Name": organization.first_name,
        "Last Name": organization.last_name,
        "email": organization.email,
        "city": organization.city,
        "hashed_password": hash_password(organization.password),
        "created_at": datetime.now(),
        "verified": True  # Set verified to True to skip email verification; set to false after implementation
    }
    organization_collection.insert_one(organization_data)
    return {"message": "Organization registered successfully"}

# Define routes for organization and volunteer
@app.get("/volunteer", response_class=HTMLResponse)
async def get_volunteer_page(request: Request):
    return templates.TemplateResponse("/volunteer/volunteer.html", {"request": request})

@app.get("/organization", response_class=HTMLResponse)
async def get_organization_page(request: Request):
    return templates.TemplateResponse("/organization/organization.html", {"request": request})































############# AUTHENTICATION FUNCTIONS #####################
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify the provided plain password against the hashed password.
    """
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def create_session_token(username: str) -> str:
    """
    Generate a session token for the authenticated user.
    """
    token = secrets.token_urlsafe(32)
    return token

def store_session_token(session_token: str, username: str, expiration_time: datetime):
    """
    Store the session token and its expiration time in the session store (MongoDB).
    """
    session_data = {
        "session_token": session_token,
        "username": username,
        "expiration_time": expiration_time
    }
    # Assuming you have a sessions_collection defined elsewhere
    sessions_collection.insert_one(session_data)

def hash_password(password: str) -> str:
    """
    Hash the provided password using bcrypt.
    """
    password_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password_bytes, salt)
    return hashed_password.decode('utf-8')

def is_password_complex(password: str) -> bool:
    """
    Check if the password meets complexity requirements.
    """
    min_length = 8
    has_lowercase = re.search(r'[a-z]', password)
    has_uppercase = re.search(r'[A-Z]', password)
    has_digit = re.search(r'\d', password)
    has_special = re.search(r'[!@#$%^&*()-_+=]', password)

    return (
        len(password) >= min_length and
        has_lowercase and
        has_uppercase and
        has_digit and
        has_special
    )
